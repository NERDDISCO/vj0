import hashlib, json, os, pathlib, shutil, subprocess, time
from datetime import datetime, timezone
root = pathlib.Path('/workspace/terminal-cast-followup-code-20260917')
progress = pathlib.Path('/workspace/terminal-cast-followup-status-20260917.json')
state = {'started_utc': datetime.now(timezone.utc).isoformat(), 'status':'running', 'jobs':[]}
def save():
    progress.write_text(json.dumps(state, indent=2) + '\n')
thread = json.loads(pathlib.Path('/workspace/terminal-threads-20260917/result.json').read_text())
if thread['status'] != 'complete':
    raise RuntimeError('Thread sweep not complete')
node_state = pathlib.Path('/proc/497/status').read_text()
if 'State:\tT' not in node_state:
    raise RuntimeError('Original Node is not paused')
safe_keys = {'PATH','LD_LIBRARY_PATH','HF_HOME','HF_HUB_CACHE','TORCHINDUCTOR_CACHE_DIR','INDUCTOR_PERSIST_DIR'}
raw = pathlib.Path('/proc/497/environ').read_bytes().split(b'\0')
selected = {x.split(b'=',1)[0].decode():x.split(b'=',1)[1].decode() for x in raw if b'=' in x and x.split(b'=',1)[0].decode() in safe_keys}
env = dict(os.environ)
env.update(selected)
env.update(CUDA_VISIBLE_DEVICES='0', HF_HUB_OFFLINE='1', COMPILE_MODE='reduce-overhead', PYTHONUNBUFFERED='1', PYTHONPATH=str(root))
python = shutil.which('python3', path=env.get('PATH'))
if not python:
    raise RuntimeError('No Python in retained safe PATH')
state['python'] = python
state['environment'] = {k:env[k] for k in sorted(safe_keys | {'CUDA_VISIBLE_DEVICES','HF_HUB_OFFLINE','COMPILE_MODE','PYTHONPATH'}) if k in env}
state['sources'] = {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in root.glob('*.py')}
save()
try:
    for label, gpu_cast in [('cpu4-cast-control',False),('gpu4-cast',True)]:
        output = pathlib.Path('/workspace/terminal-' + label + '-20260917')
        if output.exists():
            raise RuntimeError('Refusing to reuse output directory ' + str(output))
        output.mkdir()
        log = output / 'worker.log'
        argv = [python,str(root/'bench_terminal_followup.py'),'--worker-script',str(root/'inference_server.py'),'--output',str(output),'--sizes','512x288,768x448,1024x576','--steps','2','--alphas','0.1','--seeds','42','--quality-phases','3','--frames','100','--repeats','3','--warmup','4','--torch-threads','4']
        if gpu_cast:
            argv.append('--gpu-output-cast')
        job = {'label':label,'argv':argv,'output':str(output),'started_utc':datetime.now(timezone.utc).isoformat(),'status':'running'}
        state['jobs'].append(job)
        with log.open('w') as stream:
            proc = subprocess.Popen(argv,stdout=stream,stderr=subprocess.STDOUT,env=env,cwd=root)
            job['pid'] = proc.pid
            save()
            code = proc.wait()
        job.update(exit_code=code,finished_utc=datetime.now(timezone.utc).isoformat())
        result = json.loads((output/'result.json').read_text()) if (output/'result.json').exists() else {}
        job['status'] = result.get('status','missing-result')
        save()
        if code or job['status'] != 'complete':
            raise RuntimeError('Follow-up job failed: ' + label)
    state['status'] = 'complete'
except Exception as e:
    state['status'] = 'failed'
    state['error'] = str(e)
    raise
finally:
    state['finished_utc'] = datetime.now(timezone.utc).isoformat()
    save()
